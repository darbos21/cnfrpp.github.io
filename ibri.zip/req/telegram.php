<?php
$telegram_id = "7295973639";
$id_bot = "7486988253:AAFs-ibDiij0OOq-KSBmqJHcH2eERWvrqXw";
?>
